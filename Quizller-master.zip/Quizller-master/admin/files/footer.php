  <footer class="footer">
    <div class="container-fluid">
      <div class="copyright">
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script>, Powered By
        <a href="#" target="_blank">codinganddecoding</a>.
      </div>
    </div>
  </footer>
